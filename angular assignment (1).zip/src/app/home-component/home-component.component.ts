import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.scss']
})
export class HomeComponentComponent implements OnInit {
  City: any = ['pune', 'Mumbai', 'Nanded', 'Latur']
  selectedCity:any;
  constructor(public fb: FormBuilder) { }

  ngOnInit(): void {
  }
  registrationForm = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]],
    cityName: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
    phoneNumber: ['', [Validators.required, Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
    PanNumber:['', [Validators.required]],
    otp:['', [Validators.required]],
  })

  onSubmit()
  {
    console.log("on Form submit");
  }
  changeCity(e:any) {
    console.log(e.value)
    
  }
}
